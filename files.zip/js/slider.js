// $(document).ready(function(){
//   $('.slide').html("fuck me bitch");
// })

  $(document).ready(function(){
    $('.slider').bxSlider();
  });
